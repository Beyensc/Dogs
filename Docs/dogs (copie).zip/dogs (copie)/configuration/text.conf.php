<?php

$this->news='news.txt';
$this->askFile='question';

?>