contient le chemin complet vers le root du site Web</br></br>
<?php
echo 'exemple pour ce site :'.$this->appli->websitePath;
?>