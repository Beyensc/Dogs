<?php

$this->moduleTest="coucou";

?>