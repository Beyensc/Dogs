<?php
class VAdmin extends VBase
{

    function  __construct($appli,$model) {
        parent::__construct($appli,$model);
    }
   function action()
   {
      
   }


}


?>