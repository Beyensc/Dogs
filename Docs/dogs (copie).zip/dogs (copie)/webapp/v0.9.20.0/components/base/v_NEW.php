<?php
include_once('v_base.php');
class VNEW extends VBase
{

    function  __construct($appli,$model) {
        parent::__construct($appli,$model);
    }
   function action()
   {
      
   }


}


?>