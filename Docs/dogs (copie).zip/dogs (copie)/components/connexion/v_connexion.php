<?php

class VConnexion extends VBase {

    function __construct($appli, $model) {
        parent::__construct($appli, $model);
    }

      

     


    
	
}
?>