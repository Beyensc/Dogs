<?php

include_once('m_base.php');

class MNEW extends MBase {

    public function __construct($appli) {
        parent::__construct($appli);
    }

}
?>