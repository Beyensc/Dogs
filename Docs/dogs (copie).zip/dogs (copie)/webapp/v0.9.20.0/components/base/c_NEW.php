<?php
include_once('c_base.php');

class CNEW extends CBase
{

    function  __construct($appli) {
        parent::__construct($appli);
    }

   function ACTION()
   {

   }


}


?>