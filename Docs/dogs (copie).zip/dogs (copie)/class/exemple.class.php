<?php

class Exemple{
    //C'est donc ici que les classes se trouvent
}

?>